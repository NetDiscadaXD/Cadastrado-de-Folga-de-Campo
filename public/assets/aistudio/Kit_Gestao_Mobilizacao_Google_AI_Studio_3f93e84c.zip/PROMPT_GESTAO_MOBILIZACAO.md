# PROMPT DE DESENVOLVIMENTO — GESTÃO DE MOBILIZAÇÃO, FOLGA DE CAMPO E DISPONIBILIDADE

Atue como desenvolvedor Full Stack sênior e analista de dados especialista em RH, mobilização de colaboradores, gestão de pessoas e custos de projetos de engenharia.

Repositório de referência:
https://github.com/NetDiscadaXD/Cadastrado-de-Folga-de-Campo

## Objetivo
Evoluir o sistema atual de cadastro e controle de folga de campo para uma plataforma profissional de gestão de mobilização e disponibilidade de colaboradores. Preserve funcionalidades existentes, compatibilidade dos dados e integridade dos registros. Antes de alterar o código, analise a estrutura, framework, rotas, componentes, autenticação, modelo de dados e integrações atuais. Não substitua a tecnologia existente sem justificativa técnica.

## 1. Módulo “À Disposição”
Crie uma opção no menu para controlar colaboradores que estarão disponíveis para outros projetos a partir de uma data definida.

Campos:
- ID único;
- colaborador e matrícula, vinculados ao cadastro existente;
- função e projeto de origem;
- data de liberação e data efetiva de disponibilidade;
- motivo da liberação;
- projeto de destino, se definido;
- responsável pelo registro;
- status;
- observações;
- data/hora de criação e atualização.

Status:
1. Disponibilidade programada;
2. À disposição;
3. Em negociação;
4. Transferido;
5. Encerrado/cancelado.

Regras:
- Antes da data efetiva, exibir “Disponibilidade programada”.
- A partir da data efetiva, exibir “À disposição”, salvo se o registro estiver transferido, encerrado ou cancelado.
- Não disponibilizar antecipadamente.
- Ao transferir, registrar destino, data, responsável e histórico, retirando a pessoa da lista de disponíveis atuais sem apagar o histórico.
- Evitar registros ativos duplicados para a mesma pessoa.
- Permitir filtros por nome, matrícula, função, projeto, status e período.
- Permitir exportação CSV/Excel se compatível com a arquitetura existente.
- Criar alertas configuráveis para colaboradores há muitos dias à disposição.

## 2. Dashboard e indicadores
Criar painel com indicadores calculados a partir dos dados reais:
- colaboradores ativos;
- disponíveis;
- disponibilidades programadas;
- pessoas em negociação;
- transferências no período;
- folgas próximas do vencimento e vencidas, conforme as regras já existentes;
- tempo médio entre disponibilidade e transferência;
- disponíveis por projeto de origem e função;
- evolução mensal de disponibilidades e transferências;
- custo estimado de colaboradores sem alocação.

Os filtros de período, projeto, função e status devem atualizar os indicadores pertinentes. Não inventar dados: usar valores reais, zero ou estados vazios informativos.

### Custo
Permitir configurar salário mensal, encargos, benefícios, outros custos recorrentes e período do cálculo. Exibir metodologia transparente, custo diário estimado e custo acumulado. Não presumir percentuais, não duplicar encargos/benefícios e distinguir estimativa de custo efetivamente contabilizado. Se faltarem dados, informar que o cálculo não está disponível.

## 3. Módulo “Observações inteligentes”
Criar uma área acessível pelo menu e pelo perfil de cada colaborador.

Cada observação deve:
- estar vinculada ao ID do colaborador;
- armazenar conteúdo integral;
- ter categoria sugerida e categoria confirmada;
- registrar automaticamente autor e data/hora confiáveis;
- preservar histórico de alterações;
- permitir várias observações para a mesma pessoa sem sobrescrever registros anteriores.

Categorias iniciais:
- À disposição e transferência;
- Mobilização e documentação;
- Folga de campo;
- Saúde ocupacional e exames;
- Desempenho e conduta;
- Custos e benefícios;
- Transporte e hospedagem;
- Administrativo;
- Outros.

### Classificação automática
Implemente inicialmente classificação por palavras-chave/contexto, com arquitetura preparada para futura IA. Exemplos:
- “liberado pelo projeto”, “disponível para transferência”, “aguardando novo projeto” → À disposição e transferência;
- “ASO pendente”, “exame agendado”, “inapto” → Saúde ocupacional e exames;
- “folga vencida”, “passagem pendente” → Folga de campo;
- “documentação pendente”, “cadastro incompleto” → Mobilização e documentação;
- “hospedagem”, “passagem”, “adiantamento” → Custos e benefícios ou Transporte e hospedagem, conforme o contexto.

Permita sempre corrigir manualmente a categoria. Em caso de ambiguidade, sugerir “Outros” ou pedir confirmação. Não tratar hipóteses descritas na observação como fatos confirmados. Não enviar dados de RH para serviços externos de IA sem autorização, controles de segurança e avaliação de privacidade.

### Pesquisa de observações
Pesquisa global por:
- nome;
- matrícula;
- palavra ou trecho do conteúdo;
- categoria;
- responsável;
- intervalo de datas.

Exibir colaborador, matrícula, categoria, conteúdo, data/hora e autor. Permitir filtros combinados, ordenação por data e paginação. Ao selecionar um resultado, abrir o histórico do colaborador. A pesquisa deve consultar o conteúdo integral, não apenas um resumo.

## 4. Layout e rolagem
Crie interface SaaS corporativa moderna, consistente e responsiva:
- menu lateral organizado por módulos;
- cabeçalho com título, ações e usuário;
- cartões de indicadores;
- tabelas claras e responsivas;
- busca e filtros visíveis;
- formulários divididos por seções;
- etiquetas de status consistentes;
- mensagens de erro, sucesso, carregamento e estados vazios;
- confirmação para ações destrutivas;
- acessibilidade, contraste e foco visível;
- uso adequado em desktop, tablet e celular.

Corrija a rolagem:
- rolagem vertical para conteúdos longos;
- cabeçalhos de tabelas fixos quando útil;
- rolagem horizontal restrita a tabelas largas;
- evitar rolagem dupla desnecessária;
- modais, menus e painéis devem caber em telas pequenas;
- botões salvar/cancelar/pesquisar devem continuar acessíveis.

## 5. Banco de dados e segurança
Inspecione a arquitetura atual. Se utilizar Firebase/Firestore:
- criar coleções, referências e índices necessários seguindo o padrão atual;
- manter referências consistentes entre pessoas, disponibilidades e observações;
- tratar erros, paginação e ordenação;
- armazenar timestamps de forma consistente (preferencialmente UTC) e exibir no fuso America/Sao_Paulo;
- usar timestamps confiáveis do servidor quando possível;
- configurar regras de segurança e autorização por usuário/perfil;
- impedir acesso não autorizado a dados sensíveis;
- nunca expor credenciais ou chaves privadas no código público.

Preserve os dados existentes. Crie migrações ou compatibilidade retroativa quando necessário. Implemente auditoria para mudanças de status e alterações relevantes. A edição/exclusão de observações deve respeitar permissões e manter trilha de auditoria. Considerar a LGPD e política de retenção de dados de RH.

## 6. Testes e critérios de aceitação
Criar e executar testes para:
1. cadastrar disponibilidade;
2. disponibilidade futura;
3. ativação na data correta;
4. transferência com histórico preservado;
5. prevenção de duplicidade;
6. várias observações por colaborador;
7. pesquisa por nome, matrícula e palavra;
8. sugestão e edição manual de categoria;
9. autor e data/hora registrados;
10. indicadores coerentes com a base;
11. cálculo de custos com parâmetros;
12. responsividade, rolagem, filtros e paginação;
13. regras de acesso;
14. compatibilidade com funções antigas.

Não declarar conclusão apenas com telas demonstrativas. Validar persistência real e integração com o banco.

## 7. Entrega
Ao terminar:
- resumir funcionalidades implementadas;
- listar arquivos criados/alterados;
- explicar mudanças no banco e regras de segurança;
- documentar configurações/variáveis de ambiente sem revelar segredos;
- apresentar testes executados e resultados reais;
- informar limitações e etapas manuais;
- fornecer instruções para executar e publicar.

Implemente de ponta a ponta, sem substituir funcionalidades existentes por dados fictícios.

## Instrução específica para Google AI Studio
Se o ambiente não conseguir acessar diretamente o repositório, solicite ao usuário que importe/forneça os arquivos do projeto ou comece criando a aplicação a partir deste escopo. Não afirme ter modificado o GitHub se isso não aconteceu. Produza código funcional, organizado em componentes reutilizáveis, com instruções claras para configurar Firebase e variáveis de ambiente. Não inclua segredos reais no código.
